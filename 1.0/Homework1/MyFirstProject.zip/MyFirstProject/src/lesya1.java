import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class lesya1 {
    public static void main(String[] args) throws IOException {
        char[][] chars;
        int stringCount =0;
        boolean flag = true;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        /*while (flag) {

            char[] chars = reader.readLine().toCharArray();
        }*/

       /* Scanner in=new Scanner(System.in);
        System.out.println("Введите номер символа,который нужно заменить:");
        int k=in.nextInt();

        System.out.println("Введите символ,на который будем менять:");
        char sym=(char) reader.read();

            for (int i = 0; i < chars.length ; i++) {
                System.out.println(chars[i] + " ");
            }
        }*/
    }
}
