import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class first {
    public static void main(String[] args) throws IOException {
        // System.out.println();
        Scanner scanner = new Scanner(System.in);
        //int k = scanner.nextInt();
        // System.out.println(k);
        // BufferedReader bufferedReader = new BufferedReader();

        //InputStreamReader reader = new InputStreamReader(System.in);
        /*BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        String line;

        //while((line = bufferedReader.readLine()) != null) {
        while(!bufferedReader.ready()){
            System.out.println(bufferedReader.read());
            //System.out.println(line); // выводим содержимое файла на экран построчно
        }
        */

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        ArrayList <char []> charAr = new ArrayList<>();
        for (int j = 0; j < 3; j++) {
            //char[] chars = reader.readLine().toCharArray();
            charAr.add(reader.readLine().toCharArray());
            /*for (int i = 0; i < chars.length; i++) {
                System.out.print(chars[i]);
            }*/
            System.out.println();
        }

        for (int i = 0; i < 3; i++) {
            for (char ch:charAr.get(i)) {
                System.out.print(ch);
            }
        }

       /* while (true) {
           // char x = (char) reader.read();
            //System.out.println(x);
        }
        */

        /*for (int i = 0; i < 254 ; i++) {
            System.out.print("a");
        }
        System.out.println('f');
        */
        /*String s = "hi, me";
        char[] chars = s.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            System.out.println(chars[i]);
        }*/


    }

    class Numbers {
        public void setNumbers() {

        }

        public int getNumbers() {
            return 5;
        }
    }
}
