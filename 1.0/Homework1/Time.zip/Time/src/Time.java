import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Time {
    public static void main(String[] args) {
        DateFormat dF = new SimpleDateFormat("HH:mm dd.MM.yyyy");
        Date d = new Date();
        System.out.println(dF.format(d));
    }
}