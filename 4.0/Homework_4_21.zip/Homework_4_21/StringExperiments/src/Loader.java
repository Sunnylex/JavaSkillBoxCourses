import java.util.Scanner;

public class Loader {
    public static void main(String[] args) {
        String text = "Вася заработал 5000 рублей, Петя - 7563 рубля, а Маша - 30000 рублей";
        int indexOfSubMasha = text.indexOf("Маша");
        String partOfMasha = text.substring(indexOfSubMasha);
        int endIndexOfSubVasya = text.indexOf(',');
        String partOfVasya = text.substring(0, endIndexOfSubVasya);
        System.out.println(parseDigit(partOfMasha) + parseDigit(partOfVasya));
    }

    public static int parseDigit(String s) {
        String digits = "";
        for (int i = 0; i < s.length(); i++) {
            digits = (((int) s.charAt(i)) >= 48 &
                    ((int) s.charAt(i)) <= 57) ? digits + s.charAt(i) : digits + "";
        }
        return Integer.parseInt(digits);
    }
}