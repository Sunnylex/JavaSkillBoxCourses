public class Main {
    public static void main(String[] args) {
        Container container = new Container();
        container.count += 7843;
        System.out.println(sumDigits(1234567));

    }

    public static Integer sumDigits(Integer number) {
        //@TODO: write code here
        int n = number.toString().length();
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += Integer.parseInt(number.toString().charAt(i) + "");
            //sum += Integer.parseInt(Character.toString(number.toString().charAt(i))); либо так, как лучше не знаю)
        }
        return sum;
    }
}
