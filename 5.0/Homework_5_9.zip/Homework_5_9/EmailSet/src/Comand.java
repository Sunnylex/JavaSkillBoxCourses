public enum Comand {
    ADD("^ADD\\s.*"),
    LIST("^LIST$");

    private String regexMatcher;
    private Comand(String regexMatcher){
        this.regexMatcher = regexMatcher;
    }

    String getRegexMatcher(){
        return this.regexMatcher;
    }

    static Comand getComand(String s){
        for (Comand comand : Comand.values()) {
            if (s.matches(comand.getRegexMatcher())) {
                System.out.println(comand);
                return comand;
            }
        }
        return null;
    }

}
