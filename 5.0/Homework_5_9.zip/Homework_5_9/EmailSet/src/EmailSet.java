import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailSet {
    private final Pattern EMAIL_PATTERN = Pattern.compile("\\b([A-Za-z0-9.!#%&*_])+@([a-zA-Z0-9])+\\.(([a-zA-Z]){2}|([a-zA-Z]){3})$");
    private HashSet<String> emails;

    public EmailSet() {
        this.emails = new HashSet<>();

    }

    public void comand(String s) {
        if (Comand.getComand(s)!=null){
            switch (Comand.getComand(s)) {
                case ADD:
                    if (getEmail(s) != null) {
                        emails.add(getEmail(s));
                    }
                    break;
                case LIST:
                    for (String email : emails) {
                        System.out.println(email);
                    }
                    break;

                default:
                    System.out.println("Def");
            }
        }
    }

    private String getEmail(String s) {
        Matcher matcher = EMAIL_PATTERN.matcher(s);
        if (matcher.find()) {
            return s = matcher.group();
        }
        return null;
    }


}
