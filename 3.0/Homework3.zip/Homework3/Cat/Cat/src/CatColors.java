public enum CatColors {
    BLACK_CAT,
    WHITE_CAT,
    RED_CAT,    //рыжая
    SPOTY_CAT   //пятнистая
}
