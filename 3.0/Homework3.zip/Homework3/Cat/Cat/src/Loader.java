
public class Loader {
    public static void main(String[] args) {

        // первый урок:

        Cat cat = new Cat();
        Cat cat1 = new Cat();
        Cat cat2 = new Cat();
        Cat cat3 = new Cat();
        Cat cat4 = new Cat();

        System.out.println(cat.getWeight() + "\t" + cat1.getWeight() + "\t" +
                cat2.getWeight() + "\t" + cat3.getWeight() + "\t" + cat4.getWeight());


        for (; cat.getStatus() != "Exploded"; cat.feed(1000.0)) {

            System.out.println(cat.getStatus() + "\t" + cat.getWeight());
        }
        System.out.println(cat.getStatus());

        while (cat1.getStatus() != "Dead") {
            cat1.meow();
            System.out.println(cat1.getStatus() + "\t" + cat1.getWeight());
        }

        //второй урок

        System.out.println(cat.getFoodEaten());
        cat2.goToilet();

        // третий урок

        System.out.println(Cat.getCount());

        // четвертый урок

        cat3.setCatColor(CatColors.BLACK_CAT);

        // пятый урок
        Cat cat5 = new Cat(12);
        System.out.println(cat5.getStatus()+"\t"+cat5.getWeight());
        System.out.println(Cat.getCount());

        // шестой урок

        cat.setCatColor(CatColors.SPOTY_CAT);
        System.out.println(cat.getCatColor());
        System.out.println(cat3.getCatColor());
        System.out.println(cat5.getCatColor());

        // 7 lesson

        Cat cat6 = cat.clone();
        Cat cat7 = cat6.clone();

        System.out.println(Cat.getCount());






    }
}